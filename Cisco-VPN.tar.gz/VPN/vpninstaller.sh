#!/bin/bash
#
# This script is to automate the process of installing the
# Cisco VPN Client in the VAPT build of BT5. For any questions
# with installation contact James Luther.
#
echo -e "=========================================="
echo -e "Cisco VPN Installer BT5r3"
echo -e "=========================================="
echo ""
echo ""
WHOAMI=`id | sed -e 's/(.*//'`
if [ "$WHOAMI" != "uid=0" ] ; then
        echo "Sorry, you need to be root to run this script."
        exit 1
fi

echo -e "Changing file permissions in order to allow compilation of VPN Client ..."
echo ""
chmod 755 /usr/src/linux/scripts/recordmcount && chmod 755 /usr/src/linux/scripts/basic/fixdep && chmod 755 /usr/src/linux/scripts/mod/modpost
echo ""
echo -e "Extracting Cisco VPN tarball ... "
echo ""
echo ""
tar xvf vpnclient-linux-x86_64-4.8.02.0030-k9.tar.gz
echo ""
echo ""
echo -e "Patching Cisco VPN for VAPT BT5r3 ... "
echo ""
echo ""
cd ./vpnclient
patch < ../ciscovpn-bt5.patch
echo ""
echo ""
echo -e "Compiling Cisco VPN Client. Please answer no to start automatically. "
echo ""
echo ""
./vpn_install
echo ""
echo ""
echo -e "Installation Complete!"
return 0

